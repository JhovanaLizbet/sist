<!--solo se tiene contenido-->

<h1>Inicio</h1>
	<div class="container"> 
		<div class="row">
			<div class="col-md-12">
				<h1> Agregar Estudiante</h1>
<?php 
 	echo form_open_multipart('estudiante/agregarbd');
?>
					<input type="text" name="nombre" placeholder="Escriba el nombre" class="form-control">
					<input type="text" name="apellido1" placeholder="Escriba el primer apellido" class="form-control">
					<input type="text" name="apellido2" placeholder="Escriba el segundo apellido" class="form-control">

					<button type="submit" class="btn btn-success"> AGREGAR </button>
<?php
	echo form_close();
?>					
			</div>
		</div>
		
	</div>
