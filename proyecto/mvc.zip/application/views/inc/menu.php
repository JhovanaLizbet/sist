<br>
	<a href="<?php echo base_url();?>index.php/base/index">Inicio</a>
	<a href="<?php echo base_url();?>index.php/base/prod">Productos</a>
	<a href="<?php echo base_url();?>index.php/base/cont">Contactos</a>