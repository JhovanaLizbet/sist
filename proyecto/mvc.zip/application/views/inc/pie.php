<script src="<?php echo base_url(); ?>bootstrap/js/boostrap.bundle.min.js"></script>

</body>
</html>