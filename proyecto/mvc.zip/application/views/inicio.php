<!--solo se tiene contenido-->

<h1>Inicio</h1>
	<div class="container">
		<div class="row">
			<div class="col-md-12">

				<h1> Formulario</h1>
				
				<form action="#" method="POST"> 
					
					<div class="mb-3">
						<label class="form-label">Email</label>
						<input type="email" class="form-control" name="correo" placeholder="Ingresa tu email">
					</div>

					<div>
						<button type="submit" class="btn btn-primary btn-lg">Registrarse</button>
					</div>

				</form>

			</div>
		</div>
		
	</div>
