<?php

defined('BASEPATH') OR exit('No direct script access allowed'); // internamente va a gestionar las solicitudes, 
																// es linea de seguridad, no admite ejecucion //directa de script

class Estudiante extends CI_Controller // herencia
{
	public function index() //metodo
	{
		$lista=$this->estudiante_model->listaestudiantes();
		$data['estudiantes']=$lista;

		$this->load->view('inc/cabecera'); //cabezera
		$this->load->view('inc/menu'); //menu
		$this->load->view('est_lista',$data); //esta importando el archivo inicio.php  // contenido
		$this->load->view('inc/pie'); // pie 

	}

	public function agregar()
	{
		//mostrar un formulario (que va a estar en una vista) para agregar nuevo est
		$this->load->view('inc/cabecera'); //cabezera
		$this->load->view('inc/menu'); //menu
		$this->load->view('est_formulario');
		$this->load->view('inc/pie'); // pie 
	}

	public function agregarbd()
	{
		//atributo BD          formulario         
		$data['nombre']=$_POST['nombre'];
		$data['primerApellido']=$_POST['apellido1'];
		$data['segundoApellido']=$_POST['apellido2'];

		$this->estudiante_model->agregarestudiante($data);

		//redireccionamos, dirigirnos al controlador estudiante y el metoddo index
		redirect('estudiante/index','refresh');
	}
	

	public function eliminarbd()
	{
		                          //FORM
		$idestudiante=$_POST['idestudiante'];
		$this->estudiante_model->eliminarestudiante($idestudiante);
		redirect('estudiante/index','refresh');
		
	}

	public function modificar()
	{
		$idestudiante=$_POST['idestudiante'];
		$data['infoestudiante']=$this->estudiante_model->recuperarestudiante($idestudiante);
		$this->load->view('inc/cabecera'); //cabezera
		$this->load->view('inc/menu'); //menu
		$this->load->view('est_modificar',$data);
		$this->load->view('inc/pie'); // pie 
	}

	public function modificarbd()
	{
		$idestudiante=$_POST['idestudiante'];

		$data['nombre']=$_POST['nombre'];//construyendo mi array data
		$data['primerApellido']=$_POST['apellido1'];
		$data['segundoApellido']=$_POST['apellido2'];

		$this->estudiante_model->modificarestudiante($idestudiante,$data);
		redirect('estudiante/index','refresh');


	}
}
